import {z} from 'zod';
export const env=z.object({
 NEXT_PUBLIC_APP_URL:z.string().url(),NEXT_PUBLIC_SUPABASE_URL:z.string().url(),NEXT_PUBLIC_SUPABASE_ANON_KEY:z.string(),SUPABASE_SERVICE_ROLE_KEY:z.string(),
 ANTHROPIC_API_KEY:z.string(),ANTHROPIC_MODEL:z.string().default('claude-3-5-sonnet-latest'),CREATOMATE_API_KEY:z.string(),CREATOMATE_TEMPLATE_ID:z.string(),SHOTSTACK_API_KEY:z.string().optional(),
 STRIPE_SECRET_KEY:z.string(),STRIPE_WEBHOOK_SECRET:z.string(),STRIPE_PRICE_ID:z.string(),STRIPE_TRIAL_DAYS:z.coerce.number().default(7),CRON_SECRET:z.string(),
 TIKTOK_CLIENT_KEY:z.string().optional(),TIKTOK_CLIENT_SECRET:z.string().optional(),INSTAGRAM_CLIENT_ID:z.string().optional(),INSTAGRAM_CLIENT_SECRET:z.string().optional(),
 YOUTUBE_CLIENT_ID:z.string().optional(),YOUTUBE_CLIENT_SECRET:z.string().optional(),FACEBOOK_APP_ID:z.string().optional(),FACEBOOK_APP_SECRET:z.string().optional()
}).parse(process.env);
