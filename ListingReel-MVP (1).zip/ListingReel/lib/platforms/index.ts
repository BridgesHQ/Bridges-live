import type {Platform,Publisher,ConnectedAccount} from './types';
const unavailable=(p:string):Publisher=>({async refresh(a){return a},async publish(){throw new Error(`${p} account is not connected or API credentials are not configured`)},async analytics(){return {}}});
export const publishers:Record<Platform,Publisher>={tiktok:unavailable('TikTok'),instagram:unavailable('Instagram'),youtube:unavailable('YouTube'),facebook:unavailable('Facebook')};
