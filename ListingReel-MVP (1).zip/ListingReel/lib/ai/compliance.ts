const blocked=[/race/i,/religion/i,/religious/i,/christian/i,/jewish/i,/muslim/i,/islam/i,/family with children/i,/families with children/i,/kids/i,/children/i,/pregnant/i,/disab/i,/wheelchair/i,/elderly/i,/seniors/i,/perfect for/i,/ideal for/i,/great for families/i];
export function complianceFlags(text:string){return blocked.filter(r=>r.test(text)).map(r=>r.source)}
export function assertCompliant(text:string){const flags=complianceFlags(text); if(flags.length) throw new Error(`Fair Housing compliance flag: ${flags.join(', ')}`)}
