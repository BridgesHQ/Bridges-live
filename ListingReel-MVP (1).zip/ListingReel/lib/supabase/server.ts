import {createServerClient} from '@supabase/ssr'; import {cookies} from 'next/headers'; import {env} from '@/lib/env';
export function supabaseServer(){const c=cookies();return createServerClient(env.NEXT_PUBLIC_SUPABASE_URL,env.NEXT_PUBLIC_SUPABASE_ANON_KEY,{cookies:{getAll(){return c.getAll()},setAll(){}}});}
