# ListingReel

Production-oriented MVP scaffold for turning licensed real-estate listing photos into compliant short-form videos.

## Included
- Next.js 14 App Router + TypeScript + Tailwind
- Supabase Auth/Storage/Postgres schema with RLS
- 10–20 photo upload validation (JPEG/PNG, <=10 MB each)
- Claude script generation with Fair Housing guardrails and second-pass regeneration
- Script approval/edit API
- Creatomate render queue with brokerage courtesy watermark + #AIgenerated disclosure inputs
- Stripe $149/month checkout with 7-day trial and webhook persistence
- Vercel Cron render-status polling foundation
- CTA click tracking
- Platform adapter boundary for TikTok/Instagram/YouTube/Facebook
- `.env.example`

## Setup
1. Create a Supabase project and run `supabase/migrations/001_init.sql`.
2. Enable email and Google OAuth in Supabase Auth.
3. Create the `listing-photos` and `rendered-videos` buckets (migration does this).
4. Copy `.env.example` to `.env.local` and set credentials.
5. Create a Stripe Product/Price at $149/month, put its Price ID in `STRIPE_PRICE_ID`, and point Stripe webhooks to `/api/stripe/webhook`.
6. Create a Creatomate 1080x1920 template with dynamic fields matching `lib/render/creatomate.ts` (`PHOTOS`, `SCRIPT`, `ADDRESS`, `PRICE`, `AGENT`, `BROKERAGE`, `CTA`, `AI_DISCLOSURE`). Configure the template with Ken Burns transitions, captions, royalty-free music, and the brokerage watermark.
7. `npm install && npm run dev`.

## Auth
The app expects Supabase Auth. Add a login page using Supabase Auth UI or your preferred OAuth/email UI before production launch. The API routes always verify the authenticated Supabase user server-side.

## Posting APIs
Official social APIs require platform-specific app review, scopes, redirect URIs, and often business/page/channel prerequisites. The `lib/platforms` interface is deliberately isolated so each OAuth/publishing implementation can be added without changing listing/render logic. Until credentials and OAuth handlers are configured, the product must show the MP4 download fallback rather than pretending a post succeeded.

## Production hardening checklist
- Add signed upload policies and image malware/content scanning before storage.
- Move long-running Claude/Creatomate work into Inngest or a durable queue; Vercel functions should only enqueue/ack jobs.
- Encrypt OAuth refresh/access tokens at rest (KMS/envelope encryption or a secrets vault) rather than plain text.
- Add rate limits, idempotency keys, audit logs, retry/backoff, dead-letter handling, and webhook replay protection.
- Add UI for script editing/approval and connected-account OAuth flows.
- Validate CTA domains and prevent open redirects.
- Add legal/privacy/terms pages and a deletion/export flow.
- Configure Supabase Storage RLS policies for per-user objects.
