BRIDGES LIVE — self-hosting the logo & headshot (recommended)

The site references your real logo and headshot by URL, with a graceful
fallback (typeset wordmark / "DM" initials) if the CDN ever blocks them.

To make them bulletproof (never a 403, faster load), save your two images here:

  /assets/logo.webp     <- your BRIDGES logo
  /assets/dorota.webp   <- your headshot

The code already prefers these local files. If present, they win; if missing,
it falls back to your CDN URL; if that fails, to a clean typeset mark.

Download originals:
  Logo:     https://cdn.chime.me/image/fs/cmsbuild/20231116/18/h200_original_94331eed-9db3-49e3-b7af-5e259aa4f479-jpeg.webp
  Headshot: https://cdn.lofty.com/image/fs/user-info/2025125/16/w600_original_4932e9d8-2b4b-4b59-9964-496ab70ae21a-jpeg.webp
